package com.example.screen_recorder_flutter

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import androidx.core.content.ContextCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import com.example.screen_recorder_flutter.recorder.ScreenRecordService

class MainActivity : FlutterActivity() {

    private val CHANNEL = "screen_recorder"
    private val REQ_CAPTURE = 1001
    private var pendingResult: MethodChannel.Result? = null
    private lateinit var projectionManager: MediaProjectionManager

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        projectionManager = getSystemService(MediaProjectionManager::class.java)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "start" -> {
                        pendingResult = result
                        val intent = projectionManager.createScreenCaptureIntent()
                        startActivityForResult(intent, REQ_CAPTURE)
                    }
                    "stop" -> {
                        val stopIntent = Intent(this, ScreenRecordService::class.java).apply {
                            action = ScreenRecordService.ACTION_STOP
                        }
                        startService(stopIntent)

                        val uri = getSharedPreferences("recorder_prefs", MODE_PRIVATE)
                            .getString("last_video_uri", null)
                        result.success(uri)
                    }
                    else -> result.notImplemented()
                }
            }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE) {
            val res = pendingResult
            pendingResult = null
            if (resultCode == Activity.RESULT_OK && data != null) {
                val startIntent = Intent(this, ScreenRecordService::class.java).apply {
                    action = ScreenRecordService.ACTION_START
                    putExtra(ScreenRecordService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(ScreenRecordService.EXTRA_DATA_INTENT, data)
                }
                ContextCompat.startForegroundService(this, startIntent)
                res?.success(true)
            } else {
                res?.error("DENIED", "Screen capture permission denied", null)
            }
        }
    }
}
